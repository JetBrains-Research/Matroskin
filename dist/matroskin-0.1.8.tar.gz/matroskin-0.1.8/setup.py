# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['matroskin',
 'matroskin.connector',
 'matroskin.notebook',
 'matroskin.processors']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy-Utils>=0.38.3,<0.39.0',
 'SQLAlchemy>=1.4.22,<2.0.0',
 'beniget>=0.4.1,<0.5.0',
 'gast>=0.5.2,<0.6.0',
 'nbformat>=5.1.3,<6.0.0',
 'numpy>=1.21.1,<2.0.0',
 'pandas>=1.3.2,<2.0.0',
 'radon>=5.0.1,<6.0.0',
 'ray[default]>=1.5.2,<2.0.0']

setup_kwargs = {
    'name': 'matroskin',
    'version': '0.1.8',
    'description': '',
    'long_description': None,
    'author': 'Konstantin Grotov, Sergey Titov',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
